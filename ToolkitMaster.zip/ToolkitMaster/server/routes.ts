import type { Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // Weather API endpoint - proxying to a weather service
  app.get("/api/weather", async (req, res) => {
    try {
      // Using OpenWeatherMap API for Dominican Republic weather
      const API_KEY = process.env.OPENWEATHER_API_KEY || "demo_key";
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=Santo%20Domingo,DO&appid=${API_KEY}&units=metric&lang=es`
      );
      
      if (!response.ok) {
        throw new Error("Weather API unavailable");
      }
      
      const data = await response.json();
      
      const weatherData = {
        location: "Santo Domingo, RD",
        temperature: Math.round(data.main.temp),
        description: data.weather[0].description,
        humidity: data.main.humidity,
        windSpeed: Math.round(data.wind.speed * 3.6), // Convert m/s to km/h
        icon: data.weather[0].icon
      };
      
      res.json(weatherData);
    } catch (error) {
      // Fallback data if API is unavailable
      res.json({
        location: "Santo Domingo, RD",
        temperature: 28,
        description: "Datos no disponibles",
        humidity: 65,
        windSpeed: 15,
        icon: "01d"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
