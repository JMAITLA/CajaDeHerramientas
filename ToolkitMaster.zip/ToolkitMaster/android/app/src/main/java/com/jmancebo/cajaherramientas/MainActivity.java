package com.jmancebo.cajaherramientas;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
