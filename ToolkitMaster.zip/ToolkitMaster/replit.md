# Caja de Herramientas - Multi-Tool App

## Overview

This is a multi-functional web application called "Caja de Herramientas" (Toolbox) that provides various utility tools including gender and age prediction, university search, weather information, Pokemon data, and WordPress news. The application is built with a modern React frontend and Express.js backend, designed as a mobile-first Progressive Web App.

## System Architecture

The application follows a full-stack architecture with clear separation between frontend and backend components:

- **Frontend**: React with TypeScript, using Vite as the build tool
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (configured but minimal usage)
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing

## Key Components

### Frontend Architecture
- **Component Library**: shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Mobile-First Design**: Bottom navigation pattern optimized for mobile devices
- **Responsive Layout**: Flexbox-based layouts with proper spacing and typography

### Backend Architecture
- **API Routes**: RESTful endpoints for weather data and potential future features
- **Middleware**: Express middleware for JSON parsing, CORS, and request logging
- **Error Handling**: Centralized error handling with proper HTTP status codes
- **Development Tools**: Vite integration for hot module replacement in development

### Data Storage
- **Database**: PostgreSQL configured with Drizzle ORM
- **Schema**: Minimal user schema defined but not actively used
- **Memory Storage**: In-memory storage implementation for development/testing
- **Migrations**: Drizzle-kit configured for database schema management

## Data Flow

1. **Client Requests**: React components make API calls using TanStack Query
2. **API Routing**: Express server routes requests to appropriate handlers
3. **External APIs**: Server proxies requests to third-party services (weather, gender/age prediction, etc.)
4. **Response Handling**: Data flows back through the server to the client
5. **State Management**: TanStack Query caches and manages server state
6. **UI Updates**: React components re-render based on state changes

## External Dependencies

### Third-Party APIs
- **Weather Data**: OpenWeatherMap API for Dominican Republic weather
- **Gender Prediction**: genderize.io API
- **Age Prediction**: agify.io API
- **University Search**: Hipolabs Universities API
- **Pokemon Data**: PokeAPI for Pokemon information
- **WordPress News**: WordPress.com API for news content

### Key Libraries
- **UI Components**: Radix UI primitives with shadcn/ui styling
- **Database**: Drizzle ORM with Neon Database serverless driver
- **Validation**: Zod for runtime type checking
- **Date Handling**: date-fns for date manipulation
- **Icons**: Font Awesome for consistent iconography

## Deployment Strategy

The application is configured for deployment on Replit with the following considerations:

- **Build Process**: Vite builds the frontend, esbuild bundles the backend
- **Environment Variables**: Database URL and API keys configured via environment
- **Static Assets**: Frontend builds to dist/public for serving
- **Development Mode**: Vite dev server with hot reload for development
- **Production Mode**: Bundled server serves static files and API routes

The deployment strategy supports both development and production environments with proper asset handling and API proxying.

## Changelog

```
Changelog:
- July 03, 2025. Initial setup
- July 03, 2025. Updated personal information: Jonathan Mancebo, Desarrollador en Software, email and social links
- July 03, 2025. Added profile photo to header and about page
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```