import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { getWordPressNews, type NewsPost } from "@/lib/api";

export default function News() {
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [news, setNews] = useState<NewsPost[]>([]);
  const { toast } = useToast();

  const handleLoadNews = async () => {
    setLoading(true);
    try {
      const newsData = await getWordPressNews();
      setNews(newsData);
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudieron cargar las noticias. Verifica tu conexión a internet.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const stripHtml = (html: string) => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    return doc.body.textContent || "";
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-surface">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <button onClick={() => setLocation("/")} className="mr-4">
              <i className="fas fa-arrow-left text-primary-foreground text-xl"></i>
            </button>
            <h1 className="text-xl font-bold">Noticias WordPress</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center">
                  <i className="fab fa-wordpress text-white text-3xl"></i>
                </div>
                Noticias WordPress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-6">
                <Button onClick={handleLoadNews} disabled={loading} size="lg">
                  {loading ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Cargando...
                    </>
                  ) : (
                    "Cargar Últimas Noticias"
                  )}
                </Button>
              </div>

              {news.length > 0 && (
                <div className="space-y-6">
                  {news.slice(0, 3).map((post) => (
                    <article key={post.id} className="border border-border rounded-lg p-6 hover:shadow-md transition-shadow">
                      <h3 className="text-xl font-semibold mb-3">
                        {stripHtml(post.title.rendered)}
                      </h3>
                      <p className="text-muted-foreground mb-4 line-clamp-3">
                        {stripHtml(post.excerpt.rendered)}
                      </p>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">
                          {formatDate(post.date)}
                        </span>
                        <Button asChild>
                          <a href={post.link} target="_blank" rel="noopener noreferrer">
                            <i className="fas fa-external-link-alt mr-1"></i>
                            Visitar
                          </a>
                        </Button>
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
