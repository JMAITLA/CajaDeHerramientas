import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { getWeather, type WeatherData } from "@/lib/api";

export default function Weather() {
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const { toast } = useToast();

  const handleLoadWeather = async () => {
    setLoading(true);
    try {
      const weatherData = await getWeather();
      setWeather(weatherData);
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo cargar el clima. Verifica tu conexión a internet.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getWeatherIcon = (description: string) => {
    const desc = description.toLowerCase();
    if (desc.includes('sol') || desc.includes('clear')) return 'fas fa-sun';
    if (desc.includes('nub') || desc.includes('cloud')) return 'fas fa-cloud';
    if (desc.includes('lluv') || desc.includes('rain')) return 'fas fa-cloud-rain';
    if (desc.includes('tormenta') || desc.includes('storm')) return 'fas fa-bolt';
    return 'fas fa-cloud-sun';
  };

  return (
    <div className="min-h-screen bg-surface">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <button onClick={() => setLocation("/")} className="mr-4">
              <i className="fas fa-arrow-left text-primary-foreground text-xl"></i>
            </button>
            <h1 className="text-xl font-bold">Clima en República Dominicana</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Clima en República Dominicana</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-6">
                <Button onClick={handleLoadWeather} disabled={loading} size="lg">
                  {loading ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Cargando...
                    </>
                  ) : (
                    "Cargar Clima Actual"
                  )}
                </Button>
              </div>

              {weather && (
                <div className="text-center p-6 bg-gradient-to-br from-blue-400 to-blue-600 text-white rounded-lg">
                  <div className="mb-4">
                    <i className={`${getWeatherIcon(weather.description)} text-6xl mb-4`}></i>
                  </div>
                  <h3 className="text-2xl font-bold mb-2">{weather.location}</h3>
                  <div className="text-4xl font-bold mb-2">{weather.temperature}°C</div>
                  <p className="text-xl mb-2">{weather.description}</p>
                  <div className="grid grid-cols-2 gap-4 text-sm mt-4">
                    <div>
                      <i className="fas fa-tint mr-1"></i>
                      <span>Humedad: {weather.humidity}%</span>
                    </div>
                    <div>
                      <i className="fas fa-wind mr-1"></i>
                      <span>Viento: {weather.windSpeed} km/h</span>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
