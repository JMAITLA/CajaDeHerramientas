import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { predictAge, type AgePrediction } from "@/lib/api";

export default function AgePrediction() {
  const [, setLocation] = useLocation();
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AgePrediction | null>(null);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setLoading(true);
    try {
      const prediction = await predictAge(name.trim());
      setResult(prediction);
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo predecir la edad. Verifica tu conexión a internet.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getAgeCategory = (age: number | null) => {
    if (!age) return { category: "No determinado", class: "bg-gray-500 text-white", image: "" };
    
    if (age < 30) {
      return {
        category: "Joven",
        class: "bg-green-500 text-white",
        image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
      };
    } else if (age < 60) {
      return {
        category: "Adulto",
        class: "bg-blue-500 text-white",
        image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
      };
    } else {
      return {
        category: "Anciano",
        class: "bg-purple-500 text-white",
        image: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
      };
    }
  };

  return (
    <div className="min-h-screen bg-surface">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <button onClick={() => setLocation("/")} className="mr-4">
              <i className="fas fa-arrow-left text-primary-foreground text-xl"></i>
            </button>
            <h1 className="text-xl font-bold">Predictor de Edad</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Predictor de Edad</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="ageName">Nombre de la persona</Label>
                  <Input
                    id="ageName"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ingresa un nombre..."
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Prediciendo...
                    </>
                  ) : (
                    "Predecir Edad"
                  )}
                </Button>
              </form>

              {result && (
                <div className="mt-6">
                  <div className="text-center p-6 rounded-lg bg-muted">
                    {result.age && (
                      <div className="mb-4">
                        <img 
                          src={getAgeCategory(result.age).image}
                          alt="Imagen representativa de la edad"
                          className="w-32 h-32 mx-auto rounded-full object-cover shadow-lg mb-4"
                        />
                      </div>
                    )}
                    <h3 className="text-xl font-semibold mb-2 capitalize">{result.name}</h3>
                    <div className="text-3xl font-bold mb-2">
                      {result.age ? `${result.age} años` : "Edad no disponible"}
                    </div>
                    <div className={`text-lg font-medium px-4 py-2 rounded-full inline-block ${getAgeCategory(result.age).class}`}>
                      {getAgeCategory(result.age).category}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
