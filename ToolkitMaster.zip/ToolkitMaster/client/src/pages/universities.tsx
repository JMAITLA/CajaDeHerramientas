import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { searchUniversities, type University } from "@/lib/api";

export default function Universities() {
  const [, setLocation] = useLocation();
  const [country, setCountry] = useState("");
  const [loading, setLoading] = useState(false);
  const [universities, setUniversities] = useState<University[]>([]);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!country.trim()) return;

    setLoading(true);
    try {
      const results = await searchUniversities(country.trim());
      setUniversities(results);
      
      if (results.length === 0) {
        toast({
          title: "Sin resultados",
          description: "No se encontraron universidades para este país. Verifica el nombre del país en inglés.",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudieron buscar universidades. Verifica tu conexión a internet.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <button onClick={() => setLocation("/")} className="mr-4">
              <i className="fas fa-arrow-left text-primary-foreground text-xl"></i>
            </button>
            <h1 className="text-xl font-bold">Universidades por País</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Universidades por País</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="countryName">Nombre del país (en inglés)</Label>
                  <Input
                    id="countryName"
                    type="text"
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    placeholder="Ej: Dominican Republic, United States..."
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Buscando...
                    </>
                  ) : (
                    "Buscar Universidades"
                  )}
                </Button>
              </form>

              {universities.length > 0 && (
                <div className="mt-6">
                  <div className="mb-4">
                    <h3 className="text-lg font-semibold">
                      {universities.length} universidades encontradas
                    </h3>
                  </div>
                  <div className="space-y-4">
                    {universities.map((university, index) => (
                      <div key={index} className="border border-border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <h4 className="font-semibold text-lg mb-2">{university.name}</h4>
                        <p className="text-muted-foreground mb-2">
                          Dominio: {university.domains.join(", ")}
                        </p>
                        {university.web_pages.length > 0 && (
                          <a 
                            href={university.web_pages[0]} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-primary hover:underline inline-flex items-center"
                          >
                            <i className="fas fa-external-link-alt mr-1"></i>
                            Visitar página web
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
