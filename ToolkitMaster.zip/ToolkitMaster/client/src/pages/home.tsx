import { useLocation } from "wouter";
import ToolCard from "@/components/tool-card";
import profileImage from "@assets/WhatsApp Image 2025-06-05 at 22.20.11_ba6a516f_1751585667169.jpg";

export default function Home() {
  const [, setLocation] = useLocation();

  const tools = [
    {
      title: "Predictor de Género",
      description: "Predice el género basado en el nombre",
      icon: "fas fa-venus-mars",
      bgColor: "bg-gradient-to-r from-blue-500 to-pink-500",
      path: "/gender"
    },
    {
      title: "Predictor de Edad",
      description: "Estima la edad basada en el nombre",
      icon: "fas fa-birthday-cake",
      bgColor: "bg-orange-500",
      path: "/age"
    },
    {
      title: "Universidades",
      description: "Busca universidades por país",
      icon: "fas fa-university",
      bgColor: "bg-green-500",
      path: "/universities"
    },
    {
      title: "Clima RD",
      description: "Estado del tiempo en República Dominicana",
      icon: "fas fa-cloud-sun",
      bgColor: "bg-blue-400",
      path: "/weather"
    },
    {
      title: "Pokédex",
      description: "Información completa de Pokémon",
      icon: "fas fa-paw",
      bgColor: "bg-red-500",
      path: "/pokemon"
    },
    {
      title: "Noticias",
      description: "Últimas noticias de WordPress",
      icon: "fab fa-wordpress",
      bgColor: "bg-purple-500",
      path: "/news"
    }
  ];

  return (
    <div className="min-h-screen bg-surface">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white rounded-full overflow-hidden">
              <img 
                src={profileImage}
                alt="Jonathan Mancebo"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h1 className="text-xl font-bold">Caja de Herramientas</h1>
              <p className="text-blue-100 text-sm">Multi-Tool App</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-on-surface mb-4">¡Bienvenido a tu Caja de Herramientas!</h2>
          <p className="text-muted-foreground mb-6">Una aplicación que sirve para varias cosas útiles</p>
          
          {/* Toolbox image */}
          <div className="mb-8 flex justify-center">
            <img 
              src="https://images.unsplash.com/photo-1530124566582-a618bc2615dc?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Caja de herramientas con diversas herramientas" 
              className="rounded-xl shadow-lg max-w-md w-full h-auto" 
            />
          </div>
        </div>

        {/* Tool Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tools.map((tool) => (
            <ToolCard
              key={tool.path}
              title={tool.title}
              description={tool.description}
              icon={tool.icon}
              bgColor={tool.bgColor}
              onClick={() => setLocation(tool.path)}
            />
          ))}
        </div>
      </main>
    </div>
  );
}
