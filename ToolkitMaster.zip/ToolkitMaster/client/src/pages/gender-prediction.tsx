import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { predictGender, type GenderPrediction } from "@/lib/api";

export default function GenderPrediction() {
  const [, setLocation] = useLocation();
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GenderPrediction | null>(null);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setLoading(true);
    try {
      const prediction = await predictGender(name.trim());
      setResult(prediction);
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo predecir el género. Verifica tu conexión a internet.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <button onClick={() => setLocation("/")} className="mr-4">
              <i className="fas fa-arrow-left text-primary-foreground text-xl"></i>
            </button>
            <h1 className="text-xl font-bold">Predictor de Género</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Predictor de Género</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="genderName">Nombre de la persona</Label>
                  <Input
                    id="genderName"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ingresa un nombre..."
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Prediciendo...
                    </>
                  ) : (
                    "Predecir Género"
                  )}
                </Button>
              </form>

              {result && (
                <div className="mt-6">
                  <div className={`text-center p-6 rounded-lg ${
                    result.gender === 'male' ? 'gender-male' : 'gender-female'
                  }`}>
                    <div className="mb-4">
                      <div className={`w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4 ${
                        result.gender === 'male' ? 'bg-blue-500' : 'bg-pink-500'
                      } text-white`}>
                        <i className={`fas ${result.gender === 'male' ? 'fa-mars' : 'fa-venus'} text-3xl`}></i>
                      </div>
                      <h3 className="text-xl font-semibold mb-2 capitalize">{result.name}</h3>
                      <p className="text-lg">
                        {result.gender === 'male' ? 'Masculino' : result.gender === 'female' ? 'Femenino' : 'No determinado'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Probabilidad: {result.probability ? `${(result.probability * 100).toFixed(0)}%` : 'No disponible'}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
