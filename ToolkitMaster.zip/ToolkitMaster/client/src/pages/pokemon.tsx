import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { getPokemon, type PokemonData } from "@/lib/api";

export default function Pokemon() {
  const [, setLocation] = useLocation();
  const [pokemonName, setPokemonName] = useState("");
  const [loading, setLoading] = useState(false);
  const [pokemon, setPokemon] = useState<PokemonData | null>(null);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pokemonName.trim()) return;

    setLoading(true);
    try {
      const pokemonData = await getPokemon(pokemonName.trim());
      setPokemon(pokemonData);
    } catch (error) {
      toast({
        title: "Error",
        description: "Pokémon no encontrado. Verifica el nombre e intenta nuevamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const playPokemonSound = () => {
    if (pokemon?.cries?.latest) {
      const audio = new Audio(pokemon.cries.latest);
      audio.play().catch(() => {
        toast({
          title: "Error",
          description: "No se pudo reproducir el sonido del Pokémon.",
          variant: "destructive",
        });
      });
    } else {
      toast({
        title: "Sin audio",
        description: "Este Pokémon no tiene sonido disponible.",
      });
    }
  };

  return (
    <div className="min-h-screen bg-surface">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <button onClick={() => setLocation("/")} className="mr-4">
              <i className="fas fa-arrow-left text-primary-foreground text-xl"></i>
            </button>
            <h1 className="text-xl font-bold">Pokédex</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Pokédex</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="pokemonName">Nombre del Pokémon</Label>
                  <Input
                    id="pokemonName"
                    type="text"
                    value={pokemonName}
                    onChange={(e) => setPokemonName(e.target.value)}
                    placeholder="Ej: pikachu, charizard..."
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Buscando...
                    </>
                  ) : (
                    "Buscar Pokémon"
                  )}
                </Button>
              </form>

              {pokemon && (
                <div className="mt-6">
                  <div className="bg-gradient-to-br from-red-400 to-red-600 text-white rounded-lg p-6">
                    <div className="text-center mb-6">
                      <img 
                        src={pokemon.sprites.other['official-artwork'].front_default || pokemon.sprites.front_default}
                        alt={`Imagen de ${pokemon.name}`}
                        className="w-32 h-32 mx-auto mb-4 bg-white rounded-full p-2"
                      />
                      <h3 className="text-2xl font-bold capitalize mb-2">{pokemon.name}</h3>
                      <div className="flex justify-center mb-4">
                        <Button
                          onClick={playPokemonSound}
                          variant="secondary"
                          className="bg-white text-red-600 hover:bg-gray-100"
                        >
                          <i className="fas fa-volume-up mr-2"></i>
                          Reproducir Sonido
                        </Button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-white bg-opacity-20 rounded-lg p-4">
                        <h4 className="font-semibold mb-2">Experiencia Base</h4>
                        <p className="text-2xl font-bold">{pokemon.base_experience || "No disponible"}</p>
                      </div>
                      <div className="bg-white bg-opacity-20 rounded-lg p-4">
                        <h4 className="font-semibold mb-2">Habilidades</h4>
                        <div className="space-y-1">
                          {pokemon.abilities.map((ability, index) => (
                            <span 
                              key={index}
                              className="inline-block bg-white bg-opacity-30 px-2 py-1 rounded text-sm mr-1 mb-1 capitalize"
                            >
                              {ability.ability.name.replace('-', ' ')}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
