import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import profileImage from "@assets/WhatsApp Image 2025-06-05 at 22.20.11_ba6a516f_1751585667169.jpg";

export default function About() {
  const [, setLocation] = useLocation();

  const contactInfo = {
    name: "Jonathan Mancebo",
    title: "Desarrollador en Software",
    email: "Jmanceboa@outlook.com",
    linkedin: "https://www.linkedin.com/in/jonathan-mancebo-alfau-458613229/",
    github: "https://github.com/JMAITLA"
  };

  return (
    <div className="min-h-screen bg-surface">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <button onClick={() => setLocation("/")} className="mr-4">
              <i className="fas fa-arrow-left text-primary-foreground text-xl"></i>
            </button>
            <h1 className="text-xl font-bold">Acerca de</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Acerca de</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-8">
                {/* Developer photo */}
                <div className="w-32 h-32 mx-auto mb-6 rounded-full overflow-hidden shadow-lg">
                  <img 
                    src={profileImage}
                    alt="Jonathan Mancebo - Desarrollador en Software"
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-2xl font-bold mb-2">{contactInfo.name}</h3>
                <p className="text-muted-foreground mb-6">{contactInfo.title}</p>
              </div>

              <div className="space-y-4">
                <h4 className="text-lg font-semibold mb-4">Información de Contacto para Trabajos</h4>
                
                <div className="flex items-center p-4 bg-muted rounded-lg">
                  <i className="fas fa-envelope text-primary text-xl mr-4"></i>
                  <div>
                    <p className="font-medium">Email</p>
                    <p className="text-muted-foreground">{contactInfo.email}</p>
                  </div>
                </div>

                <div className="flex items-center p-4 bg-muted rounded-lg">
                  <i className="fab fa-linkedin text-primary text-xl mr-4"></i>
                  <div>
                    <p className="font-medium">LinkedIn</p>
                    <a href={contactInfo.linkedin} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                      linkedin.com/in/tu-perfil
                    </a>
                  </div>
                </div>

                <div className="flex items-center p-4 bg-muted rounded-lg">
                  <i className="fab fa-github text-primary text-xl mr-4"></i>
                  <div>
                    <p className="font-medium">GitHub</p>
                    <a href={contactInfo.github} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                      github.com/tu-usuario
                    </a>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-4 bg-primary/10 rounded-lg">
                <p className="text-sm text-muted-foreground text-center">
                  <i className="fas fa-info-circle mr-2"></i>
                  Esta aplicación fue desarrollada como parte de un proyecto educativo. 
                  El código fuente está disponible en el controlador de versiones.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
