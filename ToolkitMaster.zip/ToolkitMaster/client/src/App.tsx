import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import GenderPrediction from "@/pages/gender-prediction";
import AgePrediction from "@/pages/age-prediction";
import Universities from "@/pages/universities";
import Weather from "@/pages/weather";
import Pokemon from "@/pages/pokemon";
import News from "@/pages/news";
import About from "@/pages/about";
import BottomNavigation from "@/components/bottom-navigation";

function Router() {
  return (
    <div className="min-h-screen flex flex-col bg-surface">
      <main className="flex-1 pb-20">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/gender" component={GenderPrediction} />
          <Route path="/age" component={AgePrediction} />
          <Route path="/universities" component={Universities} />
          <Route path="/weather" component={Weather} />
          <Route path="/pokemon" component={Pokemon} />
          <Route path="/news" component={News} />
          <Route path="/about" component={About} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <BottomNavigation />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
