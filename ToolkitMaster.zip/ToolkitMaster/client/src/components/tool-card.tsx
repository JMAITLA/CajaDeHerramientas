interface ToolCardProps {
  title: string;
  description: string;
  icon: string;
  bgColor: string;
  onClick: () => void;
}

export default function ToolCard({ title, description, icon, bgColor, onClick }: ToolCardProps) {
  return (
    <div className="tool-card" onClick={onClick}>
      <div className="text-center">
        <div className={`w-16 h-16 ${bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
          <i className={`${icon} text-white text-2xl`}></i>
        </div>
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
        <p className="text-muted-foreground text-sm">{description}</p>
      </div>
    </div>
  );
}
