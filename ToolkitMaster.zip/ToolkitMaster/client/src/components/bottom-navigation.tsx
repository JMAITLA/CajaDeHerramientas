import { useLocation } from "wouter";

interface NavItem {
  path: string;
  icon: string;
  label: string;
}

const navItems: NavItem[] = [
  { path: "/", icon: "fas fa-home", label: "Inicio" },
  { path: "/weather", icon: "fas fa-cloud-sun", label: "Clima" },
  { path: "/pokemon", icon: "fas fa-paw", label: "Pokémon" },
  { path: "/news", icon: "fab fa-wordpress", label: "Noticias" },
  { path: "/about", icon: "fas fa-user", label: "Acerca de" }
];

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();

  return (
    <nav className="bg-card border-t border-border px-4 py-2 fixed bottom-0 left-0 right-0 z-50">
      <div className="flex justify-around">
        {navItems.map((item) => (
          <button
            key={item.path}
            onClick={() => setLocation(item.path)}
            className={`flex flex-col items-center py-2 px-3 transition-colors ${
              location === item.path
                ? "text-primary"
                : "text-muted-foreground hover:text-primary"
            }`}
          >
            <i className={`${item.icon} text-xl mb-1`}></i>
            <span className="text-xs">{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
