import { apiRequest } from "./queryClient";

export interface GenderPrediction {
  name: string;
  gender: 'male' | 'female' | null;
  probability: number;
  count: number;
}

export interface AgePrediction {
  name: string;
  age: number | null;
  count: number;
}

export interface University {
  name: string;
  domains: string[];
  web_pages: string[];
  country: string;
  'state-province': string | null;
  alpha_two_code: string;
}

export interface WeatherData {
  location: string;
  temperature: number;
  description: string;
  humidity: number;
  windSpeed: number;
  icon: string;
}

export interface PokemonData {
  id: number;
  name: string;
  sprites: {
    front_default: string;
    other: {
      'official-artwork': {
        front_default: string;
      };
    };
  };
  base_experience: number;
  abilities: Array<{
    ability: {
      name: string;
    };
  }>;
  cries?: {
    latest?: string;
  };
}

export interface NewsPost {
  id: number;
  title: {
    rendered: string;
  };
  excerpt: {
    rendered: string;
  };
  date: string;
  link: string;
}

export const predictGender = async (name: string): Promise<GenderPrediction> => {
  const response = await fetch(`https://api.genderize.io/?name=${encodeURIComponent(name)}`);
  if (!response.ok) {
    throw new Error('Failed to predict gender');
  }
  return response.json();
};

export const predictAge = async (name: string): Promise<AgePrediction> => {
  const response = await fetch(`https://api.agify.io/?name=${encodeURIComponent(name)}`);
  if (!response.ok) {
    throw new Error('Failed to predict age');
  }
  return response.json();
};

export const searchUniversities = async (country: string): Promise<University[]> => {
  const response = await fetch(`http://universities.hipolabs.com/search?country=${encodeURIComponent(country)}`);
  if (!response.ok) {
    throw new Error('Failed to search universities');
  }
  return response.json();
};

export const getWeather = async (): Promise<WeatherData> => {
  const response = await apiRequest('GET', '/api/weather');
  return response.json();
};

export const getPokemon = async (name: string): Promise<PokemonData> => {
  const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${encodeURIComponent(name.toLowerCase())}`);
  if (!response.ok) {
    throw new Error('Pokémon not found');
  }
  return response.json();
};

export const getWordPressNews = async (): Promise<NewsPost[]> => {
  // Using WordPress.com blog as example - can be configured for any WordPress site
  const response = await fetch('https://public-api.wordpress.com/wp/v2/sites/kinsta.com/posts?per_page=3&_fields=id,title,excerpt,date,link');
  if (!response.ok) {
    throw new Error('Failed to fetch news');
  }
  return response.json();
};
